<?php
/**
 * Settings model: pure configuration defaults and per-instance resolution.
 *
 * @package CWC_Carousel
 * @since   0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Resolves carousel configuration from the named-instance registry and
 * shortcode atts.
 *
 * Pure and side-effect-free (CM-4): `defaults()` reads the sanitized
 * `cwc_carousel_options` option with autoload off and falls back to built-in
 * defaults when the option is absent or partial (CM-1); `resolve()` merges
 * administrative defaults with explicit shortcode attributes, dropping any
 * key outside the known config set (CM-2). `count` is numeric-only via
 * absint, so a zero count yields an empty carousel and no "all" sentinel
 * exists (CM-3).
 *
 * The model is registry-aware: `registry()` reads the `cwc_carousel_registry`
 * option (autoload off, CM-7) and `resolve()` selects the named instance — or
 * the reserved `default`, never fatal (CM-8) — as the merge base. The
 * registry is read-only here: the admin writes it (AS-5) and the bootstrap
 * seeds it once (PB-4). Every resolved instance exposes exactly the 31-key
 * contract via `normalize()` (CM-9).
 *
 * @since 0.1.0
 */
class CWC_Settings {

	/**
	 * Returns the global default configuration.
	 *
	 * Reads the sanitized `cwc_carousel_options` option, aligning it over the
	 * built-in defaults so every resolved key is always present. The method
	 * never writes the option (CM-1): it falls back to built-ins when the
	 * option does not exist.
	 *
	 * @since 0.1.0
	 *
	 * @return array Global default config keyed by resolved config key.
	 */
	public function defaults(): array {
		$option = get_option( 'cwc_carousel_options', array() );

		if ( ! is_array( $option ) ) {
			$option = array();
		}

		return $this->normalize( wp_parse_args( $option, $this->builtins() ) );
	}

	/**
	 * Resolves one carousel instance's configuration.
	 *
	 * Starts from the named instance's config (the reserved `default` when
	 * `name` is absent or unknown — never fatal, CM-8) and whitelists the
	 * shortcode attributes (unknown atts are dropped), so an explicitly
	 * supplied attribute overrides the instance default (CM-2). Shortcode
	 * attributes that are empty strings are treated as "not provided" and
	 * fall through to the instance defaults — shortcode_atts() fills absent
	 * attrs with "" so they must not override the administrative values. Each
	 * named instance resolves its own config — nothing global is mutated
	 * (CM-4, SC-5). `name` is consumed here and never serializes into the
	 * resolved contract (SC-8, CM-9).
	 *
	 * @since 0.1.0
	 *
	 * @param array $atts Raw shortcode attributes.
	 * @return array Resolved config keyed by resolved config key.
	 */
	public function resolve( array $atts ): array {
		// The `name` attribute selects the instance whose config becomes the
		// merge base. It is consumed before the empty-string filter so it can
		// never participate in attribute layering or leak into the 31-key
		// contract (SC-8, CM-9). An absent/empty name resolves the reserved
		// `default` instance — today's behavior (CM-8).
		$name = isset( $atts['name'] ) ? (string) $atts['name'] : '';
		unset( $atts['name'] );

		// Normalize the name through the shared slugify() so the shortcode
		// `name` and the admin's registry slugs normalize identically (AS-8):
		// sanitize_title + underscores to hyphens. `name="Productos"` or
		// `name="mi_carousel"` therefore resolve to the stored lowercase
		// hyphenated slug instead of silently falling back to `default`.
		$name = $this->slugify( $name );

		$base = $this->instance_base( $name );

		// shortcode_atts() fills attributes the shortcode does not set with ""
		// (not null), so an empty string means "not provided": drop it so the
		// instance default applies. A string "0" is kept — count=0 still
		// yields an empty carousel per CM-3.
		$atts = array_filter(
			$atts,
			static function ( $value ) {
				return '' !== $value;
			}
		);

		$known = array(
			'type'                   => $base['type'],
			'title'                  => $base['title'],
			'category'               => $base['category'],
			'categories'             => $base['categories'],
			'mix'                    => $base['mix'],
			'count'                  => $base['count'],
			'slides'                 => $base['slides'],
			'slides_tablet'          => $base['slides_tablet'],
			'slides_mobile'          => $base['slides_mobile'],
			'gap'                    => $base['gap'],
			'arrows'                 => $base['arrows'],
			'pagination'             => $base['pagination'],
			'buy'                    => $base['buy'],
			'buy_text'               => $base['buy_text'],
			'cover'                  => $base['cover'],
			'subcategories'          => $base['subcategories'],
			'title_align'            => $base['title_align'],
			'products'               => $base['products'],
			// 13-key extension (CM-9): the base carries the new keys after
			// normalize(), so absent shortcode atts fall through to the
			// instance/builtin values.
			'autoplay'               => $base['autoplay'],
			'stop_on_hover'          => $base['stop_on_hover'],
			'timeout'                => $base['timeout'],
			'speed'                  => $base['speed'],
			'loop'                   => $base['loop'],
			'nav_position'           => $base['nav_position'],
			'nav_color_arrow'        => $base['nav_color_arrow'],
			'nav_color_bg'           => $base['nav_color_bg'],
			'nav_color_border'       => $base['nav_color_border'],
			'nav_color_arrow_hover'  => $base['nav_color_arrow_hover'],
			'nav_color_bg_hover'     => $base['nav_color_bg_hover'],
			'nav_color_border_hover' => $base['nav_color_border_hover'],
			'slides_laptop'          => $base['slides_laptop'],
		);

		return $this->normalize( wp_parse_args( $atts, $known ) );
	}

	/**
	 * Slugifies a raw name into a registry key (AS-8).
	 *
	 * Applies sanitize_title() first, then folds any remaining underscore into
	 * a hyphen so stored slugs only ever contain lowercase letters, digits and
	 * hyphens (AS-8 charset). This is the single source of truth for slug
	 * normalization: the shortcode `name` attribute in resolve() and the
	 * admin's create/edit/delete flows (class-admin.php) all funnel through
	 * here.
	 *
	 * @since 0.1.0
	 *
	 * @param string $raw Raw name.
	 * @return string Slug (lowercase letters, numbers and hyphens).
	 */
	public function slugify( string $raw ): string {
		return str_replace( '_', '-', sanitize_title( $raw, '', 'save' ) );
	}

	/**
	 * Returns the named-instance registry as a slug-keyed map.
	 *
	 * Reads the `cwc_carousel_registry` option (autoload off). A missing or
	 * non-array option reads as an empty map; reading never writes or creates
	 * the option (CM-7) — the registry is written by the admin (AS-5) and
	 * seeded once by the bootstrap migration (PB-4).
	 *
	 * @since 0.1.0
	 *
	 * @return array { slug => full_config } registry map (may be empty).
	 */
	public function registry(): array {
		$registry = get_option( 'cwc_carousel_registry', array() );

		return is_array( $registry ) ? $registry : array();
	}

	/**
	 * Returns the config base for a named instance.
	 *
	 * The supplied slug wins when present; otherwise the reserved `default`
	 * instance is used, and as a last resort the legacy defaults() — so an
	 * unknown or missing name never fails (CM-8, D3). An edited `default`
	 * takes precedence over the stale legacy option.
	 *
	 * @since 0.1.0
	 *
	 * @param string $name Instance slug (may be empty for the default).
	 * @return array Normalized 31-key config for the base.
	 */
	public function instance_base( string $name ): array {
		$registry = $this->registry();

		if ( isset( $registry[ $name ] ) && is_array( $registry[ $name ] ) ) {
			return $this->normalize( $registry[ $name ] );
		}

		if ( isset( $registry['default'] ) && is_array( $registry['default'] ) ) {
			return $this->normalize( $registry['default'] );
		}

		return $this->defaults();
	}

	/**
	 * Returns the default named instances seeded on first migration.
	 *
	 * Only a defaults source for the bootstrap migration (PB-4): the registry
	 * is never auto-overwritten once present, so user edits survive. The
	 * values match CM-10: `productos` is a product carousel at 3/2/1 with
	 * arrows, pagination and buy on; `categorias` is a category carousel at
	 * 4/2/1 with arrows and pagination on (buy/buy_text carry their builtins).
	 * Both seeds define an empty `products` list (CM-10).
	 *
	 * @since 0.1.0
	 *
	 * @return array { slug => normalized 31-key config } for the two seeds.
	 */
	public function seeds(): array {
		return array(
			'productos'  => $this->normalize(
				array(
					'type'          => 'product',
					'slides'        => 3,
					'slides_tablet' => 2,
					'slides_mobile' => 1,
					'gap'           => 16,
					'count'         => 8,
					'arrows'        => true,
					'pagination'    => true,
					'buy'           => true,
					'products'      => array(),
				)
			),
			'categorias' => $this->normalize(
				array(
					'type'          => 'category',
					'slides'        => 4,
					'slides_tablet' => 2,
					'slides_mobile' => 1,
					'gap'           => 16,
					'count'         => 8,
					'arrows'        => true,
					'pagination'    => true,
					'products'      => array(),
				)
			),
		);
	}

	/**
	 * Returns the hardcoded fallback defaults.
	 *
	 * These equal yesterday's hardcoded presentation values (slides 3/2/1,
	 * gap 16, count 8, buy on with "Comprar") so an absent option renders the
	 * same as slice 1 (CM-1, D3).
	 *
	 * @since 0.1.0
	 *
	 * @return array Built-in default values keyed by resolved config key.
	 */
	public function builtins(): array {
		return array(
			'type'                   => 'product',
			'title'                  => '',
			'category'               => 0,
			'categories'             => array(),
			'mix'                    => false,
			'count'                  => 8,
			'slides'                 => 3,
			'slides_tablet'          => 2,
			'slides_mobile'          => 1,
			'gap'                    => 16,
			'arrows'                 => true,
			'pagination'             => true,
			'buy'                    => true,
			'buy_text'               => 'Comprar',
			'cover'                  => false,
			'subcategories'          => false,
			'title_align'            => 'left',
			'products'               => array(),
			// 13-key extension (CM-12): autoplay/loop default off, hover-pause
			// and corners on, timing mid-range, nav colors empty (theme
			// default), laptop ramp one step below desktop.
			'autoplay'               => false,
			'stop_on_hover'          => true,
			'timeout'                => 3000,
			'speed'                  => 300,
			'loop'                   => false,
			'nav_position'           => 'bottom-right',
			'nav_color_arrow'        => '',
			'nav_color_bg'           => '',
			'nav_color_border'       => '',
			'nav_color_arrow_hover'  => '',
			'nav_color_bg_hover'     => '',
			'nav_color_border_hover' => '',
			'slides_laptop'          => 2,
		);
	}

	/**
	 * Sanitizes and coerces a raw config array into the resolved contract.
	 *
	 * Every key on the resolved shape is present regardless of input, and each
	 * value is coerced to its documented type so the result always serializes
	 * cleanly with wp_json_encode() (CM-4). Unknown input keys are dropped —
	 * including `name`, which resolve() consumes before merging (SC-8, CM-9).
	 *
	 * Shared coerce point (D5): resolve(), instance_base(), the bootstrap
	 * migration (PB-4), and the admin all funnel through this method so
	 * per-instance shapes never drift.
	 *
	 * @since 0.1.0
	 *
	 * @param array $config Raw config array (option or shortcode atts subset).
	 * @return array Normalized resolved config array.
	 */
	public function normalize( array $config ): array {
		$merged = wp_parse_args( $config, $this->builtins() );

		$normalized = array(
			'type'          => ( 'category' === $merged['type'] ) ? 'category' : 'product',
			'title'         => sanitize_text_field( (string) $merged['title'] ),
			'category'      => absint( $merged['category'] ),
			'categories'    => $this->sanitize_ids( $merged['categories'] ),
			'mix'           => $this->parse_bool( $merged['mix'] ),
			'count'         => absint( $merged['count'] ),
			'slides'        => absint( $merged['slides'] ),
			'slides_tablet' => absint( $merged['slides_tablet'] ),
			'slides_mobile' => absint( $merged['slides_mobile'] ),
			'gap'           => absint( $merged['gap'] ),
			'arrows'        => $this->parse_bool( $merged['arrows'] ),
			'pagination'    => $this->parse_bool( $merged['pagination'] ),
			'buy'           => $this->parse_bool( $merged['buy'] ),
			'buy_text'      => sanitize_text_field( (string) $merged['buy_text'] ),
			'cover'         => $this->parse_bool( $merged['cover'] ),
			'subcategories' => $this->parse_bool( $merged['subcategories'] ),
			'title_align'   => $this->sanitize_title_align( $merged['title_align'] ),
			'products'      => $this->sanitize_ids( $merged['products'] ),
			// 13-key extension (CM-13): booleans via parse_bool, timings and
			// the laptop ramp via absint + clamp, the corner enum via the
			// shared whitelist.
			'autoplay'      => $this->parse_bool( $merged['autoplay'] ),
			'stop_on_hover' => $this->parse_bool( $merged['stop_on_hover'] ),
			'loop'          => $this->parse_bool( $merged['loop'] ),
			'timeout'       => min( 60000, max( 1000, absint( $merged['timeout'] ) ) ),
			'speed'         => min( 5000, max( 100, absint( $merged['speed'] ) ) ),
			'slides_laptop' => min( 12, max( 1, absint( $merged['slides_laptop'] ) ) ),
			'nav_position'  => $this->sanitize_nav_position( $merged['nav_position'] ),
		);

		// Nav colors: empty passes through (theme default), any invalid hex
		// coerces to '' via sanitize_hex_color(). The empty check runs FIRST
		// because sanitize_hex_color( '' ) yields an empty string, not a
		// usable default (CM-13).
		foreach ( $this->nav_color_keys() as $color_key ) {
			$color = (string) $merged[ $color_key ];

			$normalized[ $color_key ] = ( '' === $color ) ? '' : (string) sanitize_hex_color( $color );
		}

		if ( '' === $normalized['buy_text'] ) {
			$normalized['buy_text'] = $this->builtins()['buy_text'];
		}

		return $normalized;
	}

	/**
	 * Parses a truthy/falsy shortcode value into a boolean.
	 *
	 * Accepts the string tokens WordPress conventions use for on/off ("yes",
	 * "1", "true", "on") plus actual booleans, so both administrative defaults
	 * and shortcode attributes normalize identically.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Raw boolean-ish value.
	 * @return bool Normalized boolean.
	 */
	public function parse_bool( $value ): bool {
		if ( is_bool( $value ) ) {
			return $value;
		}

		return filter_var( $value, FILTER_VALIDATE_BOOLEAN );
	}

	/**
	 * Returns the valid `title_align` enum values.
	 *
	 * Single source of truth for the title-alignment whitelist (D2): the
	 * settings model's normalize() and the admin's select renderer both consume
	 * this list, so the renderer options can never drift from the sanitizer.
	 *
	 * @since 0.1.0
	 *
	 * @return string[] Valid title-alignment values (left, center, right).
	 */
	public function title_alignments(): array {
		return array( 'left', 'center', 'right' );
	}

	/**
	 * Sanitizes a raw title-alignment value against the enum whitelist.
	 *
	 * Any value outside {left, center, right} falls back to `left` — the same
	 * rule normalize() applies when the merged config carries an invalid or
	 * absent alignment (D2). The admin's select renderer uses it to pick the
	 * selected option, and normalize() uses it as the shared coerce point.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Raw title-alignment value.
	 * @return string Valid alignment: 'left', 'center' or 'right'.
	 */
	public function sanitize_title_align( $value ): string {
		$value = (string) $value;

		return in_array( $value, $this->title_alignments(), true ) ? $value : 'left';
	}

	/**
	 * Returns the valid navigation-position values.
	 *
	 * Single source of truth for the nav-position whitelist (D2): normalize()
	 * and the admin's nav-position select renderer both consume this list, so
	 * the renderer options can never drift from the sanitizer. The four
	 * corners keep the legacy corner placement; the two side modes are the
	 * PR 6 extension (CR-11 amendment): `sides-inside` positions the arrows
	 * at the vertical middle inside the container (CSS only, no markup
	 * change), `sides-outside` moves them out of `.swiper` as flanking
	 * siblings inside a flex shell (CM-13 amendment, D6 amendment). Mirrors
	 * the title_alignments() pattern.
	 *
	 * @since 0.1.0
	 *
	 * @return string[] Valid nav-position values (bottom-right, bottom-left,
	 *                  top-right, top-left, sides-inside, sides-outside).
	 */
	public function nav_positions(): array {
		return array(
			'bottom-right',
			'bottom-left',
			'top-right',
			'top-left',
			'sides-inside',
			'sides-outside',
		);
	}

	/**
	 * Sanitizes a raw nav-position value against the whitelist.
	 *
	 * Any value outside the six positions falls back to `bottom-right` — the
	 * same rule normalize() applies when the merged config carries an invalid
	 * or absent position (CM-13, D2). The admin's select renderer uses it to
	 * pick the selected option, and normalize() uses it as the shared coerce
	 * point (title_alignments() pattern).
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Raw nav-position value.
	 * @return string Valid position: 'bottom-right', 'bottom-left',
	 *                'top-right', 'top-left', 'sides-inside' or
	 *                'sides-outside'.
	 */
	public function sanitize_nav_position( $value ): string {
		$value = (string) $value;

		return in_array( $value, $this->nav_positions(), true ) ? $value : 'bottom-right';
	}

	/**
	 * Returns the nav-color config keys.
	 *
	 * Single source of truth for the six nav-color keys (D2): normalize()
	 * coerces exactly this list, and the renderer emits one CSS variable per
	 * non-empty key, so the coercion set and the emitted set can never drift.
	 *
	 * @since 0.1.0
	 *
	 * @return string[] Valid nav-color keys (arrow, bg, border + hover pair).
	 */
	public function nav_color_keys(): array {
		return array(
			'nav_color_arrow',
			'nav_color_bg',
			'nav_color_border',
			'nav_color_arrow_hover',
			'nav_color_bg_hover',
			'nav_color_border_hover',
		);
	}

	/**
	 * Coerces a raw ID list into non-zero positive integers.
	 *
	 * Accepts an int[], a comma/whitespace-separated string, or a scalar, and
	 * re-indexes the result so only valid term or product ids remain. Shared
	 * with the admin sanitizer (class-admin.php) so both coerce identically.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $raw Raw categories value.
	 * @return int[] Sanitized positive integer IDs (may be empty).
	 */
	public function sanitize_ids( $raw ): array {
		if ( is_array( $raw ) ) {
			$ids = array_map( 'absint', $raw );
		} else {
			$ids = array_map( 'absint', wp_parse_id_list( (string) $raw ) );
		}

		return array_values(
			array_filter(
				$ids,
				static function ( $id ) {
					return $id > 0;
				}
			)
		);
	}
}
